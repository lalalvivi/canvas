import React, { useState,useEffect,useRef } from "react";
import "./App.less";
function App(this: any) {
  const [turn, setTurn] = useState<string>("black");
  const [w, setW] = useState<number>(50);
  const [h, setH] = useState<number>(55);
  const [d, setD] = useState<number>(100);
  const [e, setE] = useState<number>(20);
  const [q1, setQ1] = useState<number>(50);
  const [q2, setQ2] = useState<number>(75);
  const [q3, setQ3] = useState<number>(100);
  const [q4, setQ4] = useState<number>(120);
  const [b1, setB1] = useState<number>(20);
  const [b2, setB2] = useState<number>(35);
  const [b3, setB3] = useState<number>(50);
  const [b4, setB4] = useState<number>(70);
  const [b5, setB5] = useState<number>(140);
  const [b6, setB6] = useState<number>(160);
  const [radius, setRadiusn] = useState<number>(20);
  const [startAngle, setStartAngle] = useState<number>(0);
  const [anticlockwise, setAnticlockwise] = useState<boolean>(false);
  const [endAngle, setEndAngle] = useState<number>(Math.PI + Math.PI / 2);
  const [scaleAll, setScaleAll] = useState<number>(1);
  const [rotate, setRotate] = useState<number>(0);
  const [globalAlpha, setGlobalAlpha] = useState<number>(1);
  const [color, setColor] = useState<string>("black");
  const [colors, setColors] = useState<string>();
  const [linewidth, setLinewidth] = useState<number>(1);
  const [lineCap, setLineCap] = useState<string>("butt");
  const [lineJoin, setLineJoin] = useState<string>("miter");
  const [shadowBlur, setShadowBlur] = useState<number>(0);
  const [shadowColor, setShadowColor] = useState("rgba(0, 0, 0, 0)");
  const [shadowOffsetX, setShadowOffsetX] = useState<number>(0);
  const [shadowOffsetY, setShadowOffsetY] = useState<number>(0);
  const [fontSize, setFontSize] = useState<number>(20);
  const [fontFamily, setFontFamily] = useState<string>("serif");
  const [texTAlign, setTexTAlign] = useState<string>("start");
  const [textBaseline, setTextBaseline] = useState<string>("alphabetic");
  const [direction, setDirection] = useState<string>("inherit");
  const [textContent, setTextContent] = useState<string>();
  const [imgContent, setImgContent] = useState("");
  const [scaleSlider, setScaleSlider] = useState<number>(1);
  const [sliderx, setSliderx] = useState<number>(1);
  const [slidery, setSlidery] = useState<number>(1);
  const [sliderx1, setSliderx1] = useState<number>(100);
  const [slidery1, setSlidery1] = useState<number>(100);
  const canvas = useRef().current;
    useEffect(() => {
    change(turn);


    //处理异步数据
  }, [turn,scaleAll,scaleSlider,sliderx,slidery,sliderx1,slidery1,rotate,globalAlpha])

  function rect() {
    setTurn("rect");
    let canvas = document.getElementById("canvas");
    if (canvas) {
      if (canvas.getContext) {
        let ctx = canvas.getContext("2d");
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.rotate((rotate * Math.PI) / 180);
        ctx.globalAlpha = globalAlpha;
        var grad = ctx.createLinearGradient(0, 0, 500, 500);
        if (colors) {
          let colors1 = colors.split("-");
          grad.addColorStop(0, colors1[0]);
          grad.addColorStop(0.5, colors1[1]);
          grad.addColorStop(1, colors1[2]);
          ctx.fillStyle = grad;
        } else {
          ctx.fillStyle = color;
        }
        ctx.shadowOffsetX = shadowOffsetX;
        ctx.shadowOffsetY = shadowOffsetY;
        ctx.shadowBlur = shadowBlur;
        ctx.shadowColor = shadowColor;
        ctx.fillRect(sliderx1, slidery1, w * scaleAll, h * scaleAll);
      }
    }
  }
  function tangle() {
    setTurn("tangle");
    let canvas: any = document.getElementById("canvas");
    if (canvas.getContext) {
      let ctx = canvas.getContext("2d");
      var a = 50;
      var b = a + 25;
      var c = a - 25;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.rotate((rotate * Math.PI) / 180);
      ctx.globalAlpha = globalAlpha;
      var grad = ctx.createLinearGradient(0, 0, 500, 500);
      if (colors) {
        let colors1 = colors.split("-");
        grad.addColorStop(0, colors1[0]);
        grad.addColorStop(0.5, colors1[1]);
        grad.addColorStop(1, colors1[2]);
        ctx.fillStyle = grad;
      } else {
        ctx.fillStyle = color;
      }
      ctx.shadowOffsetX = shadowOffsetX;
      ctx.shadowOffsetY = shadowOffsetY;
      ctx.shadowBlur = shadowBlur;
      ctx.shadowColor = shadowColor;
      ctx.beginPath();
      ctx.moveTo(a * scaleAll, a * scaleAll);
      ctx.lineTo(b * scaleAll, c * scaleAll);
      ctx.lineTo(c * scaleAll, c * scaleAll);
      ctx.fill();
    }
  }
  function line() {
    setTurn("line");
    let canvas: any = document.getElementById("canvas");
    if (canvas.getContext) {
      let ctx = canvas.getContext("2d");
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.rotate((rotate * Math.PI) / 180);
      ctx.strokeStyle = color;
      ctx.shadowOffsetX = shadowOffsetX;
      ctx.shadowOffsetY = shadowOffsetY;
      ctx.shadowBlur = shadowBlur;
      ctx.shadowColor = shadowColor;
      ctx.globalAlpha = globalAlpha;
      ctx.lineWidth = linewidth;
      ctx.lineJoin = lineJoin;
      ctx.lineCap = lineCap;
      ctx.beginPath();
      ctx.lineTo(d * scaleAll, e * scaleAll);
      ctx.lineTo(d * scaleAll, (e + 100) * scaleAll);
      ctx.stroke();
    }
  }
  function arc() {
    setTurn("arc");
    let canvas: any = document.getElementById("canvas");
    if (canvas.getContext) {
      let ctx = canvas.getContext("2d");
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.rotate((rotate * Math.PI) / 180);
      ctx.globalAlpha = globalAlpha;
      ctx.lineWidth = linewidth;
      ctx.lineJoin = lineJoin;
      ctx.lineCap = lineCap;
      ctx.strokeStyle = color;
      ctx.shadowOffsetX = shadowOffsetX;
      ctx.shadowOffsetY = shadowOffsetY;
      ctx.shadowBlur = shadowBlur;
      ctx.shadowColor = shadowColor;
      ctx.beginPath();
      ctx.arc(sliderx1, slidery1, radius * scaleAll, startAngle, endAngle, anticlockwise);
      ctx.stroke();
    }
  }
  function quadratic() {
    setTurn("quadratic");
    let canvas: any = document.getElementById("canvas");
    if (canvas.getContext) {
      let ctx = canvas.getContext("2d");
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.rotate((rotate * Math.PI) / 180);
      ctx.globalAlpha = globalAlpha;
      ctx.lineWidth = linewidth;
      ctx.lineJoin = lineJoin;
      ctx.lineCap = lineCap;
      ctx.strokeStyle = color;
      ctx.shadowOffsetX = shadowOffsetX;
      ctx.shadowOffsetY = shadowOffsetY;
      ctx.shadowBlur = shadowBlur;
      ctx.shadowColor = shadowColor;
      ctx.beginPath();
      ctx.moveTo(sliderx1, slidery1);
      ctx.quadraticCurveTo(
        q1 * scaleAll,
        q2 * scaleAll,
        q3 * scaleAll,
        q4 * scaleAll
      );
      ctx.stroke();
    }
  }
  function bezier() {
    setTurn("bezier");
    let canvas: any = document.getElementById("canvas");
    if (canvas.getContext) {
      let ctx = canvas.getContext("2d");
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.rotate((rotate * Math.PI) / 180);
      ctx.globalAlpha = globalAlpha;
      ctx.lineWidth = linewidth;
      ctx.lineCap = lineCap;
      ctx.strokeStyle = color;
      ctx.shadowOffsetX = shadowOffsetX;
      ctx.shadowOffsetY = shadowOffsetY;
      ctx.shadowBlur = shadowBlur;
      ctx.shadowColor = shadowColor;
      ctx.beginPath();
      ctx.moveTo(sliderx1, slidery1);
      ctx.quadraticCurveTo(b1, b2, b3, b4, b5 * scaleAll, b6 * scaleAll);
      ctx.stroke();
    }
  }
  function pathLine() {
    setTurn("pathLine");
    let canvas: any = document.getElementById("canvas");
    if (canvas.getContext) {
      let ctx = canvas.getContext("2d");
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.rotate((rotate * Math.PI) / 180);
      ctx.strokeStyle = color;
      ctx.shadowOffsetX = shadowOffsetX;
      ctx.shadowOffsetY = shadowOffsetY;
      ctx.shadowBlur = shadowBlur;
      ctx.shadowColor = shadowColor;
      ctx.globalAlpha = globalAlpha;
      ctx.lineWidth = linewidth;
      ctx.lineJoin = lineJoin;
      ctx.lineCap = lineCap;
      ctx.beginPath();
      ctx.moveTo(d * scaleAll, e * scaleAll);
      ctx.lineTo(d * scaleAll, (e + 100) * scaleAll);
      ctx.lineTo((d + 100) * scaleAll, (e + 100) * scaleAll);
      ctx.lineTo((d + 100) * scaleAll, (e + 200) * scaleAll);
      ctx.stroke();
    }
  }
  function text() {
    setTurn("text");
    let canvas: any = document.getElementById("canvas");
    if (canvas.getContext) {
      let ctx = canvas.getContext("2d");
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.rotate((rotate * Math.PI) / 180);
      ctx.globalAlpha = globalAlpha;
      ctx.fillStyle = color;
      ctx.shadowOffsetX = shadowOffsetX;
      ctx.shadowOffsetY = shadowOffsetY;
      ctx.shadowBlur = shadowBlur;
      ctx.shadowColor = shadowColor;
      ctx.font = fontSize*scaleAll + "px" + " " + fontFamily;
      ctx.textBaseline = textBaseline;
      ctx.texTAlign = texTAlign;
      ctx.direction = direction;
      ctx.fillText(textContent, sliderx1, slidery1);
    }
  }
  function img() {
    setTurn("img");
    let canvas: any = document.getElementById("canvas");
    if (canvas.getContext) {
      let ctx = canvas.getContext("2d");
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      var img = new Image();
      function drawImage() {
        var w = canvas.width;
        var h = canvas.height;
        var sw = w * scaleSlider;
        var sh = h * scaleSlider;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, sliderx, slidery, w, h, sliderx1, slidery1, sw, sh);
      }
      img.src = imgContent;
      img.onload = function (e) {
        drawImage();
      };
    }
  }
  function clearAll() {
    let canvas: any = document.getElementById("canvas");
    if (canvas.getContext) {
      let ctx = canvas.getContext("2d");
      ctx.translate(-10, -10)	
      ctx.rotate((-rotate * Math.PI) / 180);
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      setColor('black');
      setTurn('black');
      setScaleAll(1);
      setRotate(0);
      setGlobalAlpha(1);
      setColors(String);
      setLinewidth(1);
      setLineCap('butt');
      setLineJoin('miter');
      setShadowBlur(0);
      setShadowColor("rgba(0, 0, 0, 0)");
      setShadowOffsetX(0);
      setShadowOffsetY(0);
      setFontSize(20);
      setFontFamily('serif');
      setTexTAlign('start');
      setTextBaseline('alphabetic');
      setDirection('inherit');
      setTextContent('');
      setImgContent('');
      setScaleSlider(1);
      setSliderx(1);
      setSlidery(1);
      setSliderx1(100);
      setSlidery1(100);
      }
  }
  function change(param:string) {
    switch (param) {
      case "rect":
        rect();
        break;
      case "tangle":
        tangle();
        break;
      case "line":
        line();
        break;
      case "arc":
        arc();
        break;
      case "quadratic":
        quadratic();
        break;
      case "pathLine":
        pathLine();
        break;
      case "text":
        text();
        break;
      case "bezier":
        bezier();
        break;
      case "img":
        img();
        break;
      default:
        break;
    }
  }
  function sure() {
    change(turn);
  }
  return (
    <div className="all">
      <div className="left">
        <button type="button" onClick={()=>{change('rect')}}>
          绘制矩形
        </button>
        <button type="button" onClick={()=>{change('tangle')}}>
          绘制三角形
        </button>
        <button type="button" onClick={()=>{change('line')}}>
          绘制线条
        </button>
        <button type="button" onClick={()=>{change('arc')}}>
          绘制圆弧
        </button>
        <button type="button" onClick={()=>{change('quadratic')}}>
          绘制二次贝塞尔曲线
        </button>
        <button type="button" onClick={()=>{change('bezier')}}>
          绘制三次贝塞尔曲线
        </button>
        <button type="button" onClick={()=>{change('pathLine')}}>
          绘制Path
        </button>
        {/* <button type="button">绘制SVGPath</button>  */}
        <input
          type="text"
          id="text"
          placeholder="输入文字"
          value={textContent}
          onChange={(e) => setTextContent(e.target.value)}
        ></input>
        <button type="button" onClick={()=>{change('text')}}>
          添加文字
        </button>
        <input
          type="text"
          id="img"
          placeholder="输入图片地址"
          value={imgContent}
          onChange={(e) => setImgContent(e.target.value)}
        ></input>
        <button type="button" onClick={()=>{change('img')}}>
          添加图片
        </button>
        <div>图片缩放</div>
        <input
          id="scaleSlider"
          type="range"
          min="0.1"
          max="3"
          value={scaleSlider}
          onChange={(e) => {
            {
              setScaleSlider(Number(e.target.value));
            }
          }}
          step="0.1"
        />
        <div>切片x</div>
        <input
          id="sliderx"
          type="range"
          min="0"
          max="600"
          value={sliderx}
          onChange={(e) => {
            {
              setSliderx(Number(e.target.value));
            }
          }}
          step="0.1"
        />
        <div>切片y</div>
        <input
          id="slidery"
          type="range"
          min="0"
          max="600"
          value={slidery}
          onChange={(e) => {
            {
              setSlidery(Number(e.target.value));
            }
          }}
          step="0.1"
        />
        <div>原点坐标x</div>
        <input
          id="sliderx1"
          type="range"
          min="0"
          max="600"
          value={sliderx1}
          onChange={(e) => {
            {
              setSliderx1(Number(e.target.value));
            }
          }}
          step="0.1"
        />
        <div>原点坐标y</div>
        <input
          id="slidery1"
          type="range"
          min="0"
          max="600"
          value={slidery1}
          onChange={(e) => {
            {
              setSlidery1(Number(e.target.value));
            }
          }}
          step="0.1"
        />
      </div>
      <div className="right">
        <button type="button" onClick={clearAll}>
          清除画布
        </button>
        <div className="rightContent">
          <div>缩放：</div>
          <input
            id="scale"
            type="range"
            min="0"
            max="2"
            value={scaleAll}
            onChange={(e) => {
              setScaleAll((scaleAll)=>{ return scaleAll=Number(e.target.value)});
            }}
            step="0.1"
          />
          <div>旋转：</div>
          <input
            id="rotate"
            type="range"
            min="-50"
            max="50"
            value={rotate}
            onChange={(e) => {
              {
                setRotate(Number(e.target.value));
              }
            }}
            step="0.1"
          />
          <div>透明度：</div>
          <input
            id="alpha"
            type="range"
            min="0"
            max="1"
            value={globalAlpha}
            onChange={(e) => {
              setGlobalAlpha(Number(e.target.value));
            }}
            step="0.1"
          />
          <div>颜色：</div>
          <input
            id="color"
            type="text"
            value={color}
            onChange={(e) => setColor(e.target.value)}
          />
          <div>渐变颜色：</div>
          <input
            id="gladColor"
            type="text"
            value={colors}
            onChange={(e) => setColors(e.target.value)}
          />
          <div>线条宽度：</div>
          <input
            id="lineWidth"
            type="number"
            value={linewidth}
            onChange={(e) => setLinewidth(Number(e.target.value))}
            min="0.1"
            max="10"
          />
          <div>线条末端样式：</div>
          <select
            id="lineCap"
            value={lineCap}
            onChange={(e) => setLineCap(e.target.value)}
          >
            <option value="butt">默认</option>
            <option value="round">圆形 </option>
            <option value="square">方形</option>
          </select>
          <div>线条间接合处：</div>
          <select
            id="lineJoin"
            value={lineJoin}
            onChange={(e) => setLineJoin(e.target.value)}
          >
            <option value="round">磨圆</option>
            <option value="bevel">磨平 </option>
            <option value="miter">尖角</option>
          </select>
          <div>阴影模糊：</div>
          <input
            id="shadowBlur"
            type="number"
            value={shadowBlur}
            onChange={(e) => setShadowBlur(Number(e.target.value))}
            min="0"
            max="10"
          />
          <div>阴影颜色：</div>
          <input
            id="shadowColor"
            type="text"
            value={shadowColor}
            onChange={(e) => setShadowColor(e.target.value)}
          />
          <div>阴影偏移x：</div>
          <input
            id="shadowOffsetX"
            type="number"
            value={shadowOffsetX}
            onChange={(e) => setShadowOffsetX(Number(e.target.value))}
            min="0"
            max="10"
          />
          <div>阴影偏移y：</div>
          <input
            id="shadowOffsetY"
            type="number"
            value={shadowOffsetY}
            onChange={(e) => setShadowOffsetY(Number(e.target.value))}
            min="0"
            max="10"
          />
          <div>字号：</div>
          <input
            id="fontSize"
            type="number"
            value={fontSize}
            onChange={(e) => setFontSize(Number(e.target.value))}
            min="12"
            max="60"
            step="2"
          />
          <div>字体：</div>
          <select
            id="fontFamily"
            value={fontFamily}
            onChange={(e) => setFontFamily(e.target.value)}
          >
            <option value="serif">有边饰字体</option>
            <option value="cursive">卷曲字体 </option>
            <option value="fantasy">花哨字体</option>
          </select>
          <div>文本对齐选项：</div>
          <select
            id="texTAlign"
            value={texTAlign}
            onChange={(e) => setTexTAlign(e.target.value)}
          >
            <option value="start">开始对齐</option>
            <option value="end">结束对齐 </option>
            <option value="left">左对齐</option>
            <option value="right">右对齐</option>
            <option value="center">中间对齐</option>
          </select>
          <div>基线对齐选项：</div>
          <select
            id="textBaseline"
            value={textBaseline}
            onChange={(e) => setTextBaseline(e.target.value)}
          >
            <option value="top">顶端</option>
            <option value="hanging">悬挂 </option>
            <option value="middle">正中</option>
            <option value="alphabetic">普通</option>
            <option value="ideographic">表意</option>
            <option value="bottom">底端</option>
          </select>
          <div>文本方向：</div>
          <select
            id="direction"
            value={direction}
            onChange={(e) => setDirection(e.target.value)}
          >
            <option value="ltr">从左到右</option>
            <option value="rtl">从右到左 </option>
            <option value="inherit">父继承</option>
          </select>
          <button type="button" onClick={sure}>
            确认
          </button>
        </div>
        <canvas ref={canvas} id="canvas" width="800" height="800"></canvas>
      </div>
    </div>
  );
}
export default App;
