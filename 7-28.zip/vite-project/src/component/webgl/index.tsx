import React, { memo } from 'react'

export default memo(function Webgl() {
    return (
        <div className="content">
            other
        </div>
    )
})