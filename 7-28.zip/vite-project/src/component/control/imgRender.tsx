import React , { useContext,useEffect,useState,useCallback } from 'react';
    function draw(canvasAll:React.MutableRefObject<undefined>,parameter:object,ctx:any,rotate:number,img:HTMLImageElement,sw:number,sh:number,sliderx1:number,slidery1:number){
        let canvas: any = canvasAll.current;
        img.width=sw
        img.height=sh
        let x=sliderx1,y=slidery1;
        var moveFlag=false;
        var clickFlag=false;
        var mWidth=x+img.width;
        var mHeight=y+img.height;
        canvas.onmousedown=function(e:any){
          if(e.offsetX<mWidth&&e.offsetX>x&&e.offsetY<mHeight&&e.offsetY>y){
              clickFlag=true;
              ctx.strokeStyle = 'red';
              ctx.rotate((rotate * Math.PI) / 180);
              ctx.strokeRect(x-10, y-10, img.width+20, img.height+20);
              ctx.fillRect( x-15, y-15, 10, 10);
              ctx.fillRect(img.width+x+5, y-15, 10, 10);
              ctx.fillRect( x-15, y+img.height+5, 10, 10);
              ctx.fillRect(img.width+x+5, y+img.height+5, 10, 10);  
              ctx.rotate((-rotate * Math.PI) / 180);
            }
          else{
            clickFlag=false;
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            drawImg()
          }
        }
        canvas.onmousemove=function(e:any){
          var rect = e.target.getBoundingClientRect();
          if(e.which===1&&e.offsetX<mWidth&&e.offsetX>x&&e.offsetY<mHeight&&e.offsetY>y&&clickFlag==true){
            moveFlag=true;  
            rect = e.target.getBoundingClientRect();
            x=x+e.movementX;
            y=y+e.movementY;
            mWidth=x+img.width;
            mHeight=y+img.height;
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            drawImg()
              ctx.strokeStyle = 'red';
             ctx.rotate((rotate * Math.PI) / 180);
              ctx.strokeRect(x-10, y-10, img.width+20, img.height+20);
              ctx.fillRect( x-15, y-15, 10, 10);
              ctx.fillRect(img.width+x+5, y-15, 10, 10);
              ctx.fillRect( x-15, y+img.height+5, 10, 10);
              ctx.fillRect(img.width+x+5, y+img.height+5, 10, 10);  
              ctx.rotate((-rotate * Math.PI) / 180);
            }
        }
        function drawImg() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            // ctx.translate(canvas.width / 2, canvas.height / 2);
            ctx.rotate((rotate * Math.PI) / 180);
            ctx.drawImage(img, sliderx, slidery, w, h, x,y, sw, sh,);
            // ctx.translate(canvas.width / 2, canvas.height / 2);
            ctx.rotate((-rotate * Math.PI) / 180);
      }
    }
    
