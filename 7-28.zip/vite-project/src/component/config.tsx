import{useState}from "react"
export{}
const [a, setA] = useState<number>(1); 