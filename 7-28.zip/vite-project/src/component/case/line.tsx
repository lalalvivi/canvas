import React , { useContext,useEffect,useState,useCallback } from 'react';
interface childProps{
    canvasAll:React.MutableRefObject<undefined>,
    rotate:number,
    globalAlpha:number,
    color:string,
    colors:string|undefined,
    shadowOffsetX:number,
    shadowOffsetY:number,
    shadowBlur:number,
    shadowColor:string,
    linewidth:number,
    lineJoin:string,
    lineCap:string,
    operation:string,
    lineDashx:number,
    lineDashy:number,
    lineDashOffset:number,
    sliderx1:number,
    slidery1:number,
    scaleAll:number,
    turn:string,
    changeTurn:Function,
    ctx:any,
}
const  Line:React.FC<childProps>=(props)=> {
    const {turn,ctx,changeTurn,canvasAll,rotate,globalAlpha,color,colors,shadowOffsetX,shadowOffsetY,shadowBlur,shadowColor,linewidth,lineJoin,lineCap,operation,lineDashx,lineDashy,lineDashOffset,sliderx1,slidery1,scaleAll}=props;
    useEffect(() => {
      if(turn==='line'){ draw()}
        //处理异步数据
      }, [
        scaleAll,sliderx1,slidery1,rotate,globalAlpha,operation,
        color, colors,lineDashx,lineDashOffset,linewidth,lineDashy,
        lineCap,lineJoin,turn,changeTurn,ctx,
        canvasAll,shadowBlur,shadowOffsetY,shadowColor,shadowOffsetX,
      ]);
    function draw(){
      changeTurn('line');
        let canvas: any = canvasAll.current;
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          ctx.translate(canvas.width/2,canvas.height/2);
          ctx.rotate((rotate * Math.PI) / 180);
          var grad = ctx.createLinearGradient(0, 0, 500, 500);
          if (colors) {
            let colors1 = colors.split("-");
            let a=0;
            for(let i=0;i<colors1.length;i++){
              grad.addColorStop(a, colors1[i]);
              a=a+0.5;
            }
            ctx.strokeStyle = grad;
          } else {
            ctx.strokeStyle = color;
          }
          ctx.shadowOffsetX = shadowOffsetX;
          ctx.shadowOffsetY = shadowOffsetY;
          ctx.shadowBlur = shadowBlur;
          ctx.shadowColor = shadowColor;
          ctx.globalAlpha = globalAlpha;
          ctx.lineWidth = linewidth;
          ctx.lineJoin = lineJoin;
          ctx.lineCap = lineCap;
          ctx.globalCompositeOperation = operation;
          ctx.setLineDash([lineDashx, lineDashy]);
          ctx.lineDashOffset = lineDashOffset;
          ctx.beginPath();
          ctx.lineTo(100 * scaleAll, 20 * scaleAll);
          ctx.lineTo(100 * scaleAll, (20 + 100) * scaleAll);
          ctx.stroke();
          ctx.rotate((-rotate * Math.PI) / 180);
          ctx.translate(-canvas.width/2,-canvas.height/2);

    }
    return (
        <div>
            <button
          type="button"
          onClick={draw}
        >
          绘制直线
        </button>
        </div>
    )
}
export default Line;