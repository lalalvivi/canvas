import React, { useContext, useEffect, useState, useCallback } from "react";
interface childProps {
  canvasAll: React.MutableRefObject<undefined>;
  rotate: number;
  globalAlpha: number;
  color: string;
  colors: string | undefined;
  shadowOffsetX: number;
  shadowOffsetY: number;
  shadowBlur: number;
  shadowColor: string;
  operation: string;
  sliderx1: number;
  slidery1: number;
  scaleAll: number;
  turn: string;
  changeTurn: Function;
  ctx: any;
  scaleSlider: number;
  sliderx: number;
  slidery: number;
  imgContent: string;
  changeImgContent: Function;
}
const ImgContent: React.FC<childProps> = (props) => {
  const {
    scaleSlider,
    sliderx,
    slidery,
    imgContent,
    changeImgContent,
    turn,
    ctx,
    changeTurn,
    canvasAll,
    rotate,
    globalAlpha,
    color,
    colors,
    shadowOffsetX,
    shadowOffsetY,
    shadowBlur,
    shadowColor,
    operation,
    sliderx1,
    slidery1,
    scaleAll,
  } = props;
  const [x1, setX1] = useState<number>(200);
  const [y1, setY1] = useState<number>(200);
  useEffect(() => {
    if (turn === "img") {
      draw();
    }
    //处理异步数据
  }, [
    scaleAll,
    sliderx1,
    slidery1,
    rotate,
    globalAlpha,
    operation,
    color,
    colors,
    turn,
    changeTurn,
    ctx,
    scaleSlider,
    sliderx,
    slidery,
    imgContent,
    changeImgContent,
    canvasAll,
    shadowBlur,
    shadowOffsetY,
    shadowColor,
    shadowOffsetX,
    x1,y1
  ]);
  function draw() {
    changeTurn("img");
    let canvas: any = canvasAll.current;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    var img = new Image();
      function drawImage() {
        var w=img.width;
        var h=img.height;
        var sw = w * scaleSlider;
        var sh = h * scaleSlider;
        ctx.globalCompositeOperation = operation;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.save();
        ctx.translate(x1+sw/2, y1+sh/2);
        ctx.rotate((rotate * Math.PI) / 180);
        ctx.translate(-x1-sw/2, -y1-sh/2);
        ctx.drawImage(img, sliderx, slidery, w, h, x1, y1, sw, sh);
        ctx.restore();
        img.width=sw
        img.height=sh
        let x=sliderx1,y=slidery1;
        var moveFlag=false;
        var clickFlag=false;
        var mWidth=x+img.width;
        var mHeight=y+img.height;
      
        // 鼠标按下
        canvas.onmousedown=function(e:any){
          console.log(e.offsetX,e.offsetY)
          let coords=position(sw+20,sh+20,x-10,y-10);
          let lines=getImageLines(coords);
          let points={x:e.offsetX,y:e.offsetY};
          let xPoints=findCrossPoints(points,lines)
          if( xPoints !== 0 && xPoints % 2 === 1){
            var Transparent=rgba(e.offsetX,e.offsetY);
            console.log(Transparent)
              if(Transparent){
                clickFlag=true;
                drawBorder();
              }
              else{
                clickFlag=false;
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                drawImg()
              }
            }
          else{
            clickFlag=false;
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            drawImg()
          }
        }
        canvas.onmousemove=function(e:any){
          var rect = img.getBoundingClientRect();  
          if(e.which===1&&clickFlag){
            moveFlag=true;  
            console.log(x,y)
            rect = e.target.getBoundingClientRect();
            x=x+e.movementX;
            y=y+e.movementY;
            mWidth=x+img.width;
            mHeight=y+img.height;
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            setX1(x);
            setY1(y);
            
            // drawImg();
            // drawBorder();
            }
             // 上左
          let tl:any=position(sw+20,sh+20,x-10,y-10).tl;
          let coordsTl=position(10,10,tl.x-5,tl.y-5);
          let points={x:e.offsetX,y:e.offsetY};
          let xPointsTl=controlPosition(coordsTl,points)
          // 上右
          let tr:any=position(sw+20,sh+20,x-10,y-10).tr;
          let coordsTr=position(10,10,tr.x-5,tr.y-5);
          let xPointsTr=controlPosition(coordsTr,points)
          // 上中
          let coordsTm=position(10,10,(tr.x-tl.x)/2+tl.x-5,(tr.y-tl.y)/2+tl.y-5);
          let xPointsTm=controlPosition(coordsTm,points)
           // 下左
          let bl:any=position(sw+20,sh+20,x-10,y-10).bl;
          let coordsBl=position(10,10,bl.x-5,bl.y-5);
          let xPointsBl=controlPosition(coordsBl,points)
          // 下右
          let br:any=position(sw+20,sh+20,x-10,y-10).br;
          let coordsBr=position(10,10,br.x-5,br.y-5);
          let xPointsBr=controlPosition(coordsBr,points)
          // 下中
          let coordsBm=position(10,10,(br.x-bl.x)/2+bl.x-5,(br.y-bl.y)/2+bl.y-5);
          let xPointsBm=controlPosition(coordsBm,points)
          // 最上
          var a=(tr.x-tl.x)/2+tl.x-5
          var b=(tr.y-tl.y)/2+tl.y-5
          let coordsT=position(10,10,a+35*Math.sin(rotate*Math.PI/180),b-35*Math.cos(rotate*Math.PI/180));
          let xPointsT=controlPosition(coordsT,points)
          // 左中
          let coordsLm=position(10,10,(tl.x-bl.x)/2+bl.x-5,(tl.y-bl.y)/2+bl.y-5);
          let xPointsLm=controlPosition(coordsLm,points)
          // 右中
          let coordsRm=position(10,10,(tr.x-br.x)/2+br.x-5,(tr.y-br.y)/2+br.y-5);
          let xPointsRm=controlPosition(coordsRm,points)
          if(clickFlag&&xPointsTl !== 0 && xPointsTl % 2 === 1){
            console.log('上左')
            canvas.style.cursor='nw-resize';
          }
          else if (clickFlag&&xPointsTr !== 0 && xPointsTr % 2 === 1){
            console.log('上右')
            canvas.style.cursor='ne-resize';
          }
          else if(clickFlag&&xPointsTm !== 0 && xPointsTm % 2 === 1){
            console.log('上中')
            canvas.style.cursor='n-resize';
            }
          else if(clickFlag&&xPointsBl !== 0 && xPointsBl % 2 === 1){
            console.log('下左')
            canvas.style.cursor='sw-resize';
          }
             
          else if(clickFlag&&xPointsBr !== 0 && xPointsBr % 2 === 1){
            console.log('下右')
            canvas.style.cursor='se-resize';
          }
          
          else if(clickFlag&&xPointsBm !== 0 && xPointsBm % 2 === 1){
            console.log('下中')
            canvas.style.cursor='s-resize';
            }
            
          else if(clickFlag&&xPointsT !== 0 && xPointsT % 2 === 1){
            console.log('最上')
            canvas.style.cursor='crosshair';
            }
          
          else if(clickFlag&&xPointsLm !== 0 && xPointsLm % 2 === 1){
            console.log('左中')
            canvas.style.cursor='w-resize';
            }
          
          else if(clickFlag&&xPointsRm !== 0 && xPointsRm % 2 === 1){
            console.log('右中')
            canvas.style.cursor='e-resize';
            }
            else{canvas.style.cursor='default';}           
        }

  

         // rgba判断
         function rgba(x:number,y:number){
        var _isTransparent=true;
         var myImageData = ctx.getImageData(x, y, 1, 1);
         var l = myImageData.data.length;
         for (let i = 3; i < l; i += 4) {
           let temp = myImageData.data[i];
           console.log(temp)
            _isTransparent = temp >0;
           if (_isTransparent === false) {
             break; 
           }
         }
         return _isTransparent;
         }
         
        function drawImg() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.save();
            ctx.translate(x+sw/2,y+sh/2);
            ctx.rotate((rotate * Math.PI) / 180);
            ctx.translate(-x-sw/2,-y-sh/2);
            ctx.drawImage(img, sliderx, slidery, w, h, x,y, sw, sh,);
            ctx.restore()
      }
      function drawBorder(){
        ctx.save();
        ctx.translate(+x+sw/2,y+sh/2);
        ctx.strokeStyle = 'red';
        ctx.rotate((rotate * Math.PI) / 180);
        ctx.translate(-x-sw/2,-y-sh/2);
        ctx.strokeRect(x-10, y-10, img.width+20, img.height+20);
        ctx.beginPath();
        ctx.lineTo(img.width/2+x ,  y-15 );
        ctx.lineTo(img.width/2+x , y-40 );
        ctx.stroke();
        // 上左
        control( x-15, y-15, 10, 10);
        // 上中
        control(img.width/2+x-5, y-15, 10, 10);
          // 上右
        control(img.width+x+5, y-15, 10, 10);
        // 最上
        control(img.width/2+x-5, y-50, 10, 10);
        // 左中
        control(x-15, y-5+img.height/2, 10, 10);
        // 右中
        control(img.width+x+5, y-5+img.height/2, 10, 10);
        // 下中
        control(img.width/2+x-5, y+5+img.height, 10, 10);
        // 下左
        control( x-15, y+img.height+5, 10, 10);
        // 下右
        control(img.width+x+5, y+img.height+5, 10, 10);  
        ctx.restore()
      }
      function control(ax:number,ay:number,w:number,h:number){
        ctx.fillRect( ax, ay, w, h)
      }
      }
      img.crossOrigin = "anonymous";
      img.src = imgContent;
      img.onload = function (e) {
        drawImage();
      };
      
      // if (active) {
      //   function pick(event: any, destination: any) {
      //     var x = event.layerX;
      //     var y = event.layerY;
      //     var pixel = ctx.getImageData(x, y, 1, 1);
      //     var data = pixel.data;
      //     const rgba = `rgba(${data[0]}, ${data[1]}, ${data[2]}, ${
      //       data[3] / 255
      //     })`;
      //     destination.style.backgroundColor = rgba;
      //     setColor(rgba);
      //     return rgba;
      //   }
      //   function select(event: any) {
      //     pick(event, selectedColor.current);
      //   }
      //   canvas.addEventListener("mousemove", select, false);
      //   canvas.addEventListener("click", function (event: any) {
      //     canvas.removeEventListener("mousemove", select, false);
      //     pick(event, selectedColor.current);
      //   });
      // }
  }
  // 四条直线区域
  function getImageLines(oCoords:any) {
    var lines = {
      topline: {
        o: oCoords.tl,
        d: oCoords.tr
      },
      rightline: {
        o: oCoords.tr,
        d: oCoords.br
      },
      bottomline: {
        o: oCoords.br,
        d: oCoords.bl
      },
      leftline: {
        o: oCoords.bl,
        d: oCoords.tl
      }
    };
    return lines;
};
// 点是否在区域内
function findCrossPoints(point:any, lines:any) {
  var b1, b2, a1, a2, xi, // yi,
      xcount = 0,
      iLine;

  for (var lineKey in lines) {
    iLine = lines[lineKey];
    // optimisation 1: line below point. no cross
    if ((iLine.o.y < point.y) && (iLine.d.y < point.y)) {
      continue;
    }
    // optimisation 2: line above point. no cross
    if ((iLine.o.y >= point.y) && (iLine.d.y >= point.y)) {
      continue;
    }
    // optimisation 3: vertical line case
    if ((iLine.o.x === iLine.d.x) && (iLine.o.x >= point.x)) {
      xi = iLine.o.x;
      // yi = point.y;
    }
    // calculate the intersection point
    else {
      b1 = 0;
      b2 = (iLine.d.y - iLine.o.y) / (iLine.d.x - iLine.o.x);
      a1 = point.y - b1 * point.x;
      a2 = iLine.o.y - b2 * iLine.o.x;

      xi = -(a1 - a2) / (b1 - b2);
      // yi = a1 + b1 * xi;
    }
    // dont count xi < point.x cases
    if (xi >= point.x) {
      xcount += 1;
    }
    // optimisation 4: specific for square images
    if (xcount === 2) {
      break;
    }
  }
  return xcount;
};
  //四个坐标点定位区域
  function position(sw:number,sh:number,x:number,y:number){
    var a1=Math.atan((sh/2)/(sw/2))* 180 / Math.PI
    var h1=0.5*sh/Math.sin(a1*Math.PI/180)
    // 左上角
    var y2=sh/2-h1*Math.cos((90-a1-rotate)*Math.PI/180)
    var x2=y2/Math.tan((90-a1-0.5*rotate)*Math.PI/180)
    var xLt=x-x2;
    var yLt=y+y2;
    // console.log(x2,x-x2,y+y2)
    // 右上角
    var y3=sh/2-h1*Math.sin((a1-rotate)*Math.PI/180)
    var x3=h1*Math.cos((a1-rotate)*Math.PI/180)-sw/2
    var xRt=x+x3+sw;
    var yRt=y+y3;
    // console.log(x+x3+sw,a1,Math.sin((a1-rotate)*Math.PI/180),y3,y+y3,rotate)
    // 右下角
     var y4=h1*Math.cos((90-a1-rotate)*Math.PI/180)-sh/2
     var x4=y4*Math.tan((a1+0.5*rotate)*Math.PI/180)
     var xRb=x+sw-x4;
    var yRb=y+y4+sh;
    //  console.log(x+sw-x4,y+y4+sh,rotate)
     // 左下角
     var x5=h1*Math.cos((a1-rotate)*Math.PI/180)-sw/2
     var y5=x5*Math.tan((90-a1+0.5*rotate)*Math.PI/180)
     var xLb=x-x5;
    var yLb=y+sh-y5;
    //  console.log(x-x5,y+sh-y5,rotate)
     let coords={tl:{},tr:{},br:{},bl:{}};
     coords.tl={x:xLt,y:yLt}
     coords.tr={x:xRt,y:yRt}
     coords.br={x:xRb,y:yRb}
     coords.bl={x:xLb,y:yLb}
     return coords;
     
  }
  //control定位区域
  function controlPosition(coords:any,points:any){
    let lines=getImageLines(coords);
    let point=points;
    let xPoints=findCrossPoints(point,lines)
    return xPoints
  }
  return (
    <div>
      
      <input
        type="text"
        placeholder="输入图片地址"
        value={imgContent}
        onChange={(e) => changeImgContent(e.target.value)}
      ></input>
      <div>
      <button type="button" onClick={()=>{draw();}}>
      添加图片
      </button>
      </div>
    </div>
  );
};
export default ImgContent;

